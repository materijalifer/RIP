#include <p18f2320.h>
#include <timers.h>
#include <pwm.h>
#include <delays.h>

#pragma config WDT = OFF
#pragma config PWRT= ON
#pragma config MCLRE = OFF

#define N 20 // uzimamo 20 uzoraka sinus funkcije, A = 20 isto koliko i uzoraka

unsigned int sinus[N] = {20,27,32,37,40,40,40,37,32,27,20,14,9,4,1,0,4,4,9,14}; // lookup tablica prethodno izracunata
unsigned int i = 0;

void main (){
	OpenPWM1(39); // 39+1 = 40 = 2*Amlituda
	OpenTimer2(TIMER_INT_OFF & T2_PS_1_4); // Timer2 s preddjelilom 40
	
	while(1){
		SetDCPWM1(sinus[i]<<2); // faktor popunjenosti iz tablice za i
		i++; // sljedeci faktor popunjenosti
		if (i == 20){ // ako je faktor 20, resetiraj na nulu
			i = 0;
		} // 4 naredbe traju bez izvrsavanja if-a 476us/4 preddjelilo = 119 instruckija
		// 6250 - 119 = 6131
		// 6131 je broj koji unosimo u delay funkcije
		
		Delay100TCYx(61); //6100
		Delay10TCYx(3); // 6130
		Delay1TCY(); // 6131
	}

	ClosePWM1(); // Zaustavi PWM
	CloseTimer2(); // Zaustavi Timer2

	}
	

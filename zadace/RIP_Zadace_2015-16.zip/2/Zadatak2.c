#include <p18f1220.h>

#pragma config WDT = OFF
#pragma config PWRT= ON
#pragma config MCLRE=OFF


unsigned int brzina; // brzina
unsigned int start = 1; // prvi brid
unsigned int brojac = 0; // brojac preljeva



void high_isr(void); // prototip prekidne rutine

#pragma code high_vector=0x08 // adresa prekidnog vektora

void interrupt_at_high_vector(void)
{
     _asm GOTO high_isr _endasm // prekidna rutina
}
#pragma code // kraj 

#pragma interrupt high_isr // prekidna rutina

void high_isr (void) {
   if(PIR1bits.TMR1IF) { // ako je timer1 generirao prekid, preljev
      PIR1bits.TMR1IF = 0; // obrisi zastavicu
      brojac++; // brojac ++
		T1CON = 0xC9; // ponovo pokreni brojac
   }
   
   else if(PIR1bits.CCP1IF){ // prekid je generirao CCP1
   
	  PIR1bits.CCP1IF = 0;
      if (start){ // prvi brid
		start = 0; // obrisi start (drugi brid)
		brojac = 0; // brojac na 0
		T1CON = 0xC9; // Timer1 ponovo start
		TMR1H = 0x00; // brisemo brojac
		TMR1L = 0x00;
	   }
		else{
			brzina = 0.02/((float)(brojac * 65536 + CCPR1H * 256 + CCPR1L) / 10000000);
			brojac = 0; // brojac na nulu
			start = 1; // ponovo prvi brid novo vozilo
	   }
   }
}
#pragma code

void main() { 

   TRISB = 0xFF; // svi pinovi na picu su ulazni
   PORTB = 0x00; // ocistimo PORTB
   
   RCON = 0x80; // b'00001000' za prioritetne prekide
   IPR1 = 0x05; // postavi prioritet CCP1 i TIMER1
   PIE1 = 0x05; // omoguci prekid CCP1 i TIMER1
   
   CCP1CON = 0x05; // Postavimo u capture mod na rasteci brid (prolazak vozila
   T3CON = 0x00; // Postavimo Timer1 kao izvor za CCP1
   
   PIR1 = 0x00; // ocisti zastavicu Timer1
    
   INTCON = 0xC0; // Dozvoli prekide GIE i PEIE
    
   T1CON = 0xC9; // Timer1 16bitni mod, bez prescalera, spojen na Fosc
   while (1){
      // "koristan posao
   }
   
 }


#include <p18f1220.h>
#pragma config WDT = OFF
#pragma config PWRT= ON
#pragma config MCLRE=OFF // zadano

unsigned int stanje = 1; // globalna varijabla stanje
unsigned int start = 1; // globalna varijabla start
unsigned int maska; // globalna varijabla maska

void high_isr(void); // prototip prekida

#pragma code high_vector=0x08 // prekidni vektor

void interrupt_at_high_vector(void){
     _asm GOTO high_isr _endasm // prekidna rutina 
}
#pragma code // gotov prekidni vektor

#pragma interrupt high_isr // prekidna rutina višeg prioriteta

void high_isr (void){ // pocetak prekidne rutine
   INTCON = 0xA0; // Dozvoli prekide preko INTCON, b'10100000' postavi GIE i TMR0IE
   T0CON = 0x88; // 16 bit brojac, postavi na interni oscilator, pokreni
   
   if(stanje == 0 || stanje == 2){ // crveno ili zeleno
      TMR0H = 0xCF; // 5 sekundi, oko 65536 – 12500 = 53046
      TMR0L = 0x30; //    eksperimentalna vrijednost
   }
   
   else { // zuto
      TMR0H = 0xEC; // 2 sekunde, +- ms
      TMR0L = 0x8C; // eksperimentalna vrijednost
   }
   
   if (start) { // ako je start i stanje 3, gotovo je s pocetkom 
      if (stanje == 3){
	 start = 0;
      }	
   }
   
   
   if (stanje == 0) maska = 0x14; // sva 4 stanja za semafor
   if (stanje == 1) maska = 0x32;
   if (stanje == 2) maska = 0x41;
   if (stanje == 3) maska = 0x23;
   
   if (start) {
      if (stanje == 0) maska = 0x11; // sva 4 stanja, ali drugi semafor uvijek u crvenom
      if (stanje == 1) maska = 0x31;
      if (stanje == 2) maska = 0x41;
      if (stanje == 3) maska = 0x21;      
   }
   
   
   PORTB = maska; // zapisi masku na izlazne portove
   
   stanje++; // povecaj stanje
   
   if (stanje > 3) { // ako je stanje vece od 3 resetiraj
      stanje = 0;
   }
}
   
#pragma code // gotov prekidni vektor


void main() { 
    PORTB = 0; // brisemo port B    
    TRISB = 0; // Svi portovi B su konfigurirani kao izlazni
    RCON = 0; // onemoguci prioritete prekida
    INTCON = 0xA0; // Dozvoli prekide preko INTCON, b'10100000' postavi GIE i TMR0IE
    T0CON = 0x88; // 16 bit brojac, postavi na interni oscilator, pokreni
    TMR0H = 0xCF; // postavljamo trajanje od 5 sekundi, oko 65536 – 12500 = 53046
    TMR0L = 0xB0; // eksperimentalna vrijednost
	
    PORTB = 0x11; // b'00010001' oba semafora crveno
    
    while (1){
		// "koristan rad"
	}
 }

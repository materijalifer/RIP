#include <p18f2320.h>
#include <timers.h>
#include <delays.h>
#include <reset.h>
#include <spi.h>
#include <usart.h>
#include <stdlib.h>

#pragma config WDT = ON
#pragma config WDTPS = 256

#pragma config PWRT= ON
#pragma config MCLRE=OFF

float lookup[13] = {0.0012, 0.0033, 0.0091, 0.0254, 0.0711, 0.1993, 0.5623, 1.6053, 4.6983, 14.5071, 50.8071, 258.0626,1000};

unsigned int adc;
unsigned char rezultat;
unsigned int pomak;
unsigned char Izracunaj ();


void high_isr(void); // prekidna funkcija

#pragma code high_vector=0x08 // prekidni vektor

void interrupt_at_high_vector(void){
     _asm GOTO high_isr _endasm // prekidna rutinu
}
#pragma code // kraj prekidnog vektora

#pragma interrupt high_isr // visoki prioritet
void high_isr (void){   
        
     if(ReadUSART() == '?'){ // RS-232 i ?, ukoliko je racunaj 	
		putsUSART(Izracunaj()); // zapisi vrijednost funkcije izracunaj
     }
     
     INTCONbits.GIE =1; // ponovo omoguci prekid
	 INTCONbits.PEIE =1; // ponovo omoguci prekid
}
#pragma code // kraj programskog koda prekidne rutine

unsigned char Izracunaj ()
{
   
   for (pomak = 15; pomak >= 0; pomak--)    { // 16 bitova, prvih 12 korisnih (adc), zadnja 4 ne
      if ((adc >> pomak) == 1) break; // prva jedinica binarno, pogledaj tablicu, pretvaranje u ASCII
   }  
   
   itoa(lookup[pomak], rezultat); // itoa integer u ascii
   
   return rezultat;
}

unsigned char MSPI ( unsigned char data_out ) { // preuzeto
  
   unsigned char TempVar;  
   TempVar = SSPBUF;           // Clears BF
   PIR1bits.SSPIF = 0;         // Clear interrupt flag
   SSPCON1bits.WCOL = 0;			//Clear any previous write collision
   SSPBUF = data_out;           // write byte to SSPBUF register
   if ( SSPCON1 & 0x80 )   {
      // test if write collision occurred
      return ( -1 );              // if WCOL bit is set return negative #
   }
   else   {      
      while( !PIR1bits.SSPIF );  // wait until bus cycle complete
   }
	 
    // nastavak
   adc = SSPBUF * 256; // Citamo visih 8 bitova, shiftamo ulijevo  
      
   PIR1bits.SSPIF = 0;      // preuzeto
   SSPBUF = 0x00;           // initiate bus cycle
   
   while(!PIR1bits.SSPIF);  // wait until cycle complete
    adc = adc + SSPBUF; // sad citamo donjih 8 bitova i zbrajamo, dobijamo 16 bitova, prvih 12 korisnio, zadnjih 4 ne koristimo
      
   return ( 0 );                // if WCOL bit is not set return non-negative# // zadano
}

void main()
{
	INTCONbits.GIE = 1;
	INTCONbits.PEIE = 1; // Omogući prekide GIE,PEIE = 1
	TRISAbits.TRISA0 = 0; // CS izlazni na AD
   
	OpenSPI(SPI_FOSC_16, MODE_00, SMPEND); // Otvaramo SPI konekciju, inicijalizacija
   
   
	OpenUSART(USART_TX_INT_OFF & USART_RX_INT_ON & USART_ASYNCH_MODE & USART_NINE_BIT & USART_CONT_RX & USART_BRGH_HIGH, 15);
	// USART, TX off, RX on, ASYNC, 9 bitova (8+1 stop), kontinuirani RX, BRGH - high baudrate, 15 spbrg
   
   while(1)   {      
      LATAbits.LATA0 = 0; // /CS u 0, aktivacija
      Delay1TCY(); // Na frekv. PIC-a od 4,9152, izvodenje je 1,2288, cekamo 2x
      Delay1TCY(); // 2x
	  
      MSPI(0x0C); // Modificirani SPI za citanje i pisanje
      
      LATAbits.LATA0 = 1; // /CS u 1, gotov SPI

      WriteSPI(0xE0); // ADC U spavanje, 1110 0000 power down    
      Sleep(); // PIC spava dok ga WDT ne probudi
   }
}
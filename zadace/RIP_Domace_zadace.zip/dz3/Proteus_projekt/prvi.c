#include <p18f2320.h>
#include <timers.h>
#include <pwm.h>
#include <delays.h>

#pragma config WDT = OFF
#pragma config PWRT= ON
#pragma config MCLRE = OFF

#define N 25 // sinus se uzorkuje na 25 mjesta i amplituda je 25

unsigned int sinus[N] = 
{25,31,37,42,46,48,49,49,47,44,39,34,28,21,
		  15,10,5,2,0,0,1,3,7,12,18}; // prethodno izra�unata lookup tablica
unsigned int i = 0;

void main (){
   
	OpenPWM1(100); 		//PR2 = 100
	OpenTimer2(TIMER_INT_OFF & T2_PS_1_4); //  Uklju�i timer2, preddjelilo = 4
	
	while(1){		// beskona�na petlja
		SetDCPWM1(sinus[i]<<2); // postavi popunjenost prema lookup tablici
		i++; // uve�aj broja�
		if (i == N) // ako je broja� do�ao do kraja perioda
		     i = 0;	// zapo�ni sljede�i period
		
		Delay100TCYx(48); // 4881 ciklusa �ekanja
		Delay10TCYx(8.1); // 5000 - 119 ciklusa koji se tro�e na naredbe u petlji
	}

	ClosePWM1(); // Isklju�i PWM
	CloseTimer2(); // Isklju�i Timer2

}
	


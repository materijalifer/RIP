#include <p18f2320.h>
#include <spi.h>
#include <usart.h>
#include <reset.h>
#include <delays.h>
#include <stdlib.h>

#pragma config WDT = ON
#pragma config PWRT= ON
#pragma config MCLRE=OFF
#pragma config WDTPS = 4096		// watchdog ceka 16.384s

float lookup_table[13] = {0.0012, 0.0033, 0.0091, 0.0254, 
      0.0711, 0.1993, 0.5623, 1.6053, 4.6983, 14.5071, 50.8071, 258.0626, 1000};

// deklaracije varijabli
unsigned int i;
unsigned int value;
unsigned char ascii_value;

void high_isr(void);   // prototip prekidne rutine

#pragma code high_vector = 0x08    // direktiva pretprocesoru: slijedi prekidni vektor

void interrupt_at_high_vector(void)
{
     _asm GOTO high_isr _endasm		// skok na prekidnu rutinu
}
#pragma code

#pragma interrupt high_isr	// direktiva pretprocesoru: slijedi prekidna rutina
					  // visokog prioriteta
void high_isr (void){   
        
     if(ReadUSART() == '?') {	
	 for (i = 15; i >= 0; i--)	// nadji polozaj prve jedinice
	    if ((value >> i) == 1) break; 
   
	itoa(lookup_table[i], ascii_value); // nadji vrijednost u lookup tablici
					     // i pretvori ju u ascii
	putsUSART(ascii_value);		// posalji vrijednost na usart
     }
     INTCON |= 0xc0;	// odobri prekide
}
#pragma code

/**
   Originalni WriteSPI modificiran da vraca sadrzaj SSPBUF
   registra na izlasku iz funkcije
*/
unsigned char WriteSPI_c ( unsigned char data_out ) { // preuzeto
  
   unsigned char TempVar;  
   TempVar = SSPBUF;           // Clears BF
   
   // citanje visih 8 bitova
   PIR1bits.SSPIF = 0;         // Clear interrupt flag
   SSPBUF = data_out;           // write byte to SSPBUF register
   if ( SSPCON1 & 0x80 )   {
      // test if write collision occurred
      return ( -1 );              // if WCOL bit is set return negative #
   }
   else   {      
      while( !PIR1bits.SSPIF );  // wait until bus cycle complete
   }

   value = SSPBUF * 256; // uzimamo gornjih 8 bitova; radimo shift u lijevo za 8
      
   // citanje nizih 8 bitova
   PIR1bits.SSPIF = 0;		// Clear interrupt flag
   SSPBUF = 0x00;           // write byte to SSPBUF register
   
   while(!PIR1bits.SSPIF);  // wait until bus cycle complete
   value += SSPBUF; 		// uzimamo donjih 8 bitova
      
   return ( 0 );                // if WCOL bit is not set return non-negative# // zadano
}

void main()
{
   INTCON = 0xc0;	// odobri prekide
   TRISA = 0x00;	// port A izlazni
   
   OpenSPI(SPI_FOSC_16, MODE_00, SMPEND); // otvori spi vezu
   OpenUSART(USART_TX_INT_OFF & USART_RX_INT_ON & USART_ASYNCH_MODE & 
      USART_NINE_BIT & USART_CONT_RX & USART_BRGH_HIGH, 15);	// otvori usart vezu
   
   while(1)   {      	// beskonacna petlja
      LATA &= 0xfe;	// aktiviraj a/d pretvornik
      // potrebno cekati 1.425us; jedan ciklus-> 0.2us
      Delay1TCY();Delay1TCY();Delay1TCY();Delay1TCY();
      Delay1TCY();Delay1TCY();Delay1TCY();
      
      WriteSPI_c(0x0c); // LSB first, BIP
      LATA |= 0x01; // zaustavi a/d pretvorni
      WriteSPI(0xe0); // stavi a/d u sleep mode    
      Sleep(); // sleep -> cekanje watchdoga
   }
}
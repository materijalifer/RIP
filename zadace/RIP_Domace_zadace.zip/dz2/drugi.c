#include <p18f1220.h>

#pragma config WDT = OFF
#pragma config PWRT = ON
#pragma config MCLRE = OFF

unsigned int brzina;
unsigned int oc = 0;
unsigned int i = 0;

void high_isr(void);   // prototip prekidne rutine

#pragma code high_vector = 0x08    // direktiva pretprocesoru: slijedi prekidni vektor

void interrupt_at_high_vector(void)
{
     _asm GOTO high_isr _endasm		// skok na prekidnu rutinu
}
#pragma code

#pragma interrupt high_isr	// direktiva pretprocesoru: slijedi prekidna rutina
					  // visokog prioriteta
void high_isr(void)
{
     if(PIR1 & 0x01)		// prekid od timer1
     {
	 oc += 1;		// povecaj brojac preljeva
	 T1CON = 0xc9;		// ponovno pokreni timer1
	 PIR1 &= 0xfe;		// resetiraj prekid
     }
     if(PIR1 & 0x04)		// prekid od ccp1
     {
            PIR1 &= 0xfb;	// resetiraj prekid od ccp1
            if(!i)		// ako je prvi rastuci brid
            {
                  i += 1;		// povecaj brojac za 1 da se zna da je prosao
                  T1CON = 0xc9;		// resetiraj brojac
                  TMR1H = 0x00;
                  TMR1L = 0x00;
            }                  
            else		// drugi rastuci brid; racunaj brzinu
            {
                  i = 0;	// ponisti brojac
                  brzina = 0.02 / ( (float)(oc * 65536 + CCPR1H * 256 + CCPR1L) * 0.0000001 );
            }
	    oc = 0;		// ponisti brojac preljeva
     }

}

# pragma code		// kraj prekidnog vektora

void main(void)
{
     TRISB = 0xff;  // port B ulazni
     PORTB = 0;     // postavljanje porta B na 0
     RCON = 0x80;   // omogucavanje prioritetnih prekida
     
     IPR1 = 0x05;   // postavljanje prioriteta prekida
     PIE1 = 0x05;   // omoguci prekide ccp1 i timer1
     CCP1CON = 0x05;   // capture mode / rastuci brid signala
     T3CON = 0x00;     // timer1 izvor za ccp1
     PIR1 = 0x00;      // ocisti zastavicu za timer1
     INTCON = 0xc0;    // omogucavanje prekida

     T1CON = 0xc;      // podesavanje timera1

     while(1);         // petlja cekalica

}
#include <p18f1220.h>

#pragma config WDT = OFF
#pragma config PWRT = ON
#pragma config MCLRE = OFF

#define _2secL 0x8D	// konstanta za cekanje 2 sekunde
#define _2secH 0xEC
#define _5secL 0x44	// konstanta za cekanje 5 sekundi
#define _5secH 0xCF

unsigned char state;	// globalna varijabla za spremanje stanja

void high_isr(void);   // prototip prekidne rutine

#pragma code high_vector = 0x08    // direktiva pretprocesoru: slijedi prekidni vektor

void interrupt_at_high_vector(void)
{
     _asm GOTO high_isr _endasm		// skok na prekidnu rutinu
}
#pragma code

#pragma interrupt high_isr	// direktiva pretprocesoru: slijedi prekidna rutina
					  // visokog prioriteta
void high_isr(void)
{
     if(INTCON & 0x04)		// provjera da li je doslo do prekida od timera 0
     {
               INTCON &= 0xfb;		// ponisti prekid da bi se mogao ponovno dogoditi
               if(state % 2 == 0)	// u parnim stanjima se ceka 2, a u neparnim 5 sekundi
               {
                        TMR0H = _2secH;		// postavljanje brojila na 2 sekunde
                        TMR0L = _2secL;
               }
               else
               {
                        TMR0H = _5secH;		// postavljanje brojila na 5 sekundi
                        TMR0L = _5secL;
               }

	       switch(state)		// ovisno o stanju, postavi odgovarajucu vrijednost
	       {				// na port B
		  case 0:		// stanje 0,1 i 2 su sinkronizacijska; 3,4,5,6 se vrte beskonacno
		     PORTB = 0x31;	// L: cr/zu R: cr
		     break;
		  case 1:
		     PORTB = 0x41;	// L: ze R: cr
		     break;
		  case 2:
		     PORTB = 0x23;	// L: zu R: cr/zu
		     break;
		  case 3:
		     PORTB = 0x14;	// L: cr R: ze
		     break;
		  case 4:
		     PORTB = 0x32;	// L: cr/zu R: zu
		     break;
		  case 5:
		     PORTB = 0x41;	// L: zel R: crv
		     break;
		  case 6:
		     PORTB = 0x23;	// L: zu R: cr/zu
	       }
	       
               if(state == 6)		// ako je stanje 6, vrati se na stanje 3
                        state = 3;
	       else			// inace povecaj stanje
			state += 1;

     }
}

# pragma code		// kraj prekidnog vektora

void main(void)
{
     PORTB = 0;      // pocisti port B
     TRISB = 0;      // sve linije izlazne
     RCON = 0;       // svi prekidi jednakog prioriteta

     PORTB = 0x11;    // pocetno svima crveno

     INTCON = 0xa0;  // dopustanje prekida
     T0CON = 0x88;   // ukljucivanje brojila

     TMR0H = 0xCF;      // pocetna vrijednost u timeru
     TMR0L = 0x63;

     state = 0;      // postavi stanje na 0

     while(1);       // petlja cekalica
}